<?php

require "config/database.php";

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $nombre = $_POST["nombre"];
    $email = $_POST["email"];

    $password = password_hash(
        $_POST["password"],
        PASSWORD_DEFAULT
    );

    $sql = "INSERT INTO usuarios
            (nombre,email,password)
            VALUES (?,?,?)";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        $nombre,
        $email,
        $password
    ]);

    echo "Usuario registrado";
}
?>

<?php require "includes/header.php"; ?>

<h2>Registro</h2>

<form method="POST">

Nombre:

<input type="text"
name="nombre"
required>

<br><br>

Email:

<input type="email"
name="email"
required>

<br><br>

Password:

<input type="password"
name="password"
required>

<br><br>

<button type="submit">

Registrarse

</button>

</form>
