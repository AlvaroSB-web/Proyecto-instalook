<?php

session_start();

if(
!isset($_SESSION["usuario"])
){

    header(
        "Location: login.php"
    );

    exit;
}
?>

<?php require "includes/header.php"; ?>

<h2>Zona Privada</h2>

<p>

Bienvenido

<?php

echo $_SESSION["usuario"];

?>

</p>

<a href="logout.php">

Cerrar sesión

</a>
