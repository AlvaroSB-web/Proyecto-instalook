<?php

session_start();

require "../config/database.php";

$sql =
"SELECT *
FROM productos";

$stmt =
$pdo->query($sql);

$productos =
$stmt->fetchAll();

?>

<h1>

Products

</h1>

<a href="create_product.php">

New Product

</a>

<hr>

<?php
foreach(
$productos
as $producto
):
?>

<p>

<?= $producto['nombre'] ?>

-

€<?= $producto['precio'] ?>

<a
href="edit_product.php?id=<?=
$producto['id']
?>">

Edit

</a>

<a
href="delete_product.php?id=<?=
$producto['id']
?>">

Delete

</a>

</p>

<?php endforeach; ?>
