<?php

session_start();

require "../config/database.php";

if(
$_SERVER["REQUEST_METHOD"]
==
"POST"
){

$sql =
"INSERT INTO productos
(
nombre,
descripcion,
precio,
stock,
categoria_id
)

VALUES
(
?,
?,
?,
?,
?
)";

$stmt =
$pdo->prepare($sql);

$stmt->execute([

$_POST["nombre"],

$_POST["descripcion"],

$_POST["precio"],

$_POST["stock"],

$_POST["categoria"]

]);

header(
"Location: products.php"
);

exit;
}
?>

<form method="POST">

Nombre

<input
type="text"
name="nombre">

<br><br>

Descripción

<textarea
name="descripcion">
</textarea>

<br><br>

Precio

<input
type="number"
step="0.01"
name="precio">

<br><br>

Stock

<input
type="number"
name="stock">

<br><br>

Categoría ID

<input
type="number"
name="categoria">

<br><br>

<button>

Guardar

</button>

</form>
