<?php

session_start();

require "../config/database.php";

$id =
$_GET["id"];

if(
$_SERVER["REQUEST_METHOD"]
==
"POST"
){

$sql =
"UPDATE productos
SET

nombre=?,

descripcion=?,

precio=?,

stock=?

WHERE id=?";

$stmt =
$pdo->prepare($sql);

$stmt->execute([

$_POST["nombre"],

$_POST["descripcion"],

$_POST["precio"],

$_POST["stock"],

$id

]);

header(
"Location: products.php"
);

exit;
}

$sql =
"SELECT *
FROM productos
WHERE id=?";

$stmt =
$pdo->prepare($sql);

$stmt->execute([$id]);

$producto =
$stmt->fetch();

?>

<form method="POST">

Nombre

<input
type="text"
name="nombre"
value="<?= $producto['nombre'] ?>">

<br><br>

Descripción

<textarea
name="descripcion"><?= $producto['descripcion'] ?></textarea>

<br><br>

Precio

<input
type="number"
step="0.01"
name="precio"
value="<?= $producto['precio'] ?>">

<br><br>

Stock

<input
type="number"
name="stock"
value="<?= $producto['stock'] ?>">

<br><br>

<button>

Actualizar

</button>

</form>
