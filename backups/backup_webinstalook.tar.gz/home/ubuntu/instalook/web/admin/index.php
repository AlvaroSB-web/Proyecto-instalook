<?php

session_start();

if(
!isset($_SESSION["rol"])
||
$_SESSION["rol"]!="admin"
){

die(
"Access denied"
);

}
?>

<h1>

Admin Panel

</h1>

<ul>

<li>

<a href="products.php">

Manage Products

</a>

</li>

</ul>
