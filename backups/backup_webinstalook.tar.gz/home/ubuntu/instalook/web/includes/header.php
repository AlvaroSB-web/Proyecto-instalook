<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>InstaLook</title>

<link rel="stylesheet"
href="style.css">

</head>

<body>

<h1>InstaLook</h1>

<nav>

<a href="index.php">
Home
</a>

|

<a href="products.php">
Products
</a>

|

<a href="cart.php">

Cart

</a>

|

<a href="login.php">
Login
</a>

|

<a href="register.php">
Register
</a>

</nav>

<hr>
