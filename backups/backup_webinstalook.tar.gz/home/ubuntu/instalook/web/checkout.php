<?php

session_start();

require "config/database.php";

if(
!isset($_SESSION["usuario"])
){

die(
"You must login first"
);

}

if(
empty($_SESSION["carrito"])
){

die(
"Cart empty"
);

}

$email = null;

$sql =
"SELECT *
FROM usuarios
LIMIT 1";

$stmt =
$pdo->query($sql);

$usuario =
$stmt->fetch();

$ids =
implode(
",",
$_SESSION["carrito"]
);

$sql =
"SELECT *
FROM productos
WHERE id IN ($ids)";

$stmt =
$pdo->query($sql);

$productos =
$stmt->fetchAll();

$total = 0;

foreach(
$productos
as $producto
){

$total +=
$producto["precio"];
}

$sql =
"INSERT INTO pedidos
(usuario_id,total)
VALUES(?,?)";

$stmt =
$pdo->prepare($sql);

$stmt->execute([
$usuario["id"],
$total
]);

$pedido_id =
$pdo->lastInsertId();

foreach(
$productos
as $producto
){

$sql =
"INSERT INTO detalles_pedido
(
pedido_id,
producto_id,
cantidad,
precio
)

VALUES
(
?,
?,
?,
?
)";

$stmt =
$pdo->prepare($sql);

$stmt->execute([

$pedido_id,

$producto["id"],

1,

$producto["precio"]

]);
}

unset(
$_SESSION["carrito"]
);

echo "
Pedido realizado correctamente
";
