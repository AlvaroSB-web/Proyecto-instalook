<?php

session_start();

require "config/database.php";

if($_SERVER["REQUEST_METHOD"]=="POST"){

    $email = $_POST["email"];

    $password = $_POST["password"];

    $sql = "SELECT * FROM usuarios
            WHERE email=?";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([$email]);

    $usuario = $stmt->fetch();

    if(
        $usuario &&
        password_verify(
            $password,
            $usuario["password"]
        )
    ){

        $_SESSION["usuario"] =
$usuario["nombre"];

$_SESSION["usuario_id"] =
$usuario["id"];

$_SESSION["rol"] =
$usuario["rol"];

        header(
            "Location: dashboard.php"
        );

        exit;

    }else{

        echo "Credenciales incorrectas";
    }
}
?>

<?php require "includes/header.php"; ?>

<h2>Login</h2>

<form method="POST">

Email:

<input type="email"
name="email"
required>

<br><br>

Password:

<input type="password"
name="password"
required>

<br><br>

<button type="submit">

Entrar

</button>

</form>
