<?php

require "config/database.php";

$sql = "
SELECT
productos.*,
categorias.nombre AS categoria
FROM productos
INNER JOIN categorias
ON productos.categoria_id = categorias.id
";

$stmt = $pdo->query($sql);

$productos = $stmt->fetchAll();

?>

<?php require "includes/header.php"; ?>

<h2>Products</h2>

<?php foreach($productos as $producto): ?>

<div class="card">

<img
src="images/<?=
$producto['imagen']
?>"
width="200">

<h3>
<?= $producto['nombre'] ?>
</h3>

<p>
<?= $producto['descripcion'] ?>
</p>

<p>
<?= $producto['categoria'] ?>
</p>

<p>
€<?= $producto['precio'] ?>
</p>

<form action="add_to_cart.php"
method="POST">

<input
type="hidden"
name="id"
value="<?= $producto['id'] ?>">

<button type="submit">

Add to Cart

</button>

</form>

</div>

<hr>

<?php endforeach; ?>
