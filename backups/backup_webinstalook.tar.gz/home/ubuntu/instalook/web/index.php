<?php require "includes/header.php"; ?>

<h2>Welcome to InstaLook</h2>

<p>
Modern fashion for everyone.
</p>

<ul>

<li>
<a href="products.php">
View Products
</a>
</li>

<li>
<a href="register.php">
Register
</a>
</li>

<li>
<a href="login.php">
Login
</a>
</li>

</ul>
