<?php

session_start();

$id = $_POST["id"];

if(
!isset($_SESSION["carrito"])
){

    $_SESSION["carrito"] = [];
}

$_SESSION["carrito"][] = $id;

header(
"Location: products.php"
);
